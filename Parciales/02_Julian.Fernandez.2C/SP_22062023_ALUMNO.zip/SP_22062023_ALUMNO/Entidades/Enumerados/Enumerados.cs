﻿namespace Entidades.Enumerados
{
    public enum EIngrediente { ADHERESO =5, QUESO = 10, JAMON = 12, HUEVO = 13, PANCETA = 15 };
}