﻿using Entidades.Enumerados;


namespace Entidades.MetodosDeExtension
{
    public class IngredientesExtension
    {

    }
}
