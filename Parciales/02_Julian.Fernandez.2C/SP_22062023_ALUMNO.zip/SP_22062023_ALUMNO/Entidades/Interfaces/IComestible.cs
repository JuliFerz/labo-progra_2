﻿namespace Entidades.Interfaces
{
    public interface IComestible
    {


    }
}
