﻿using Entidades.Exceptions;
using Entidades.Files;
using Entidades.Interfaces;


namespace Entidades.Modelos
{


    public class Cocinero 
    {
        private int cantPedidosFinalizados;
        private string nombre;
        private double demoraPreparacionTotal;



        public Cocinero(string nombre)
        {
            this.nombre = nombre;
        }


        public bool HabilitarCocina
        {
            get => true;
        }

        public double TiempoMedioDePreparacion { get => this.cantPedidosFinalizados == 0 ? 0 : this.demoraPreparacionTotal / this.cantPedidosFinalizados; }
        public string Nombre { get => nombre; }

        private void IniciarIngreso()
        {

        }

        private void NotificarNuevoIngreso()
        {

        }
        private void EsperarProximoIngreso()
        {

        }
    }
}
